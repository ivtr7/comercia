import { MapPin, User, Rocket } from 'lucide-react';
import logo from '@/assets/logo-comercia.png';

export default function Footer() {
  return (
    <footer className="py-8 md:py-10 lg:py-12 border-t border-border bg-background-secondary">
      <div className="container mx-auto px-4 sm:px-6">
        <div className="grid md:grid-cols-3 gap-6 md:gap-8 items-center">
          {/* Logo & Info */}
          <div className="space-y-2 md:space-y-3 text-center md:text-left">
            <img src={logo} alt="ComercIA" className="h-8 md:h-10 w-auto mx-auto md:mx-0" />
            <p className="text-xs md:text-sm text-muted-foreground">
              Soluções em Inteligência Artificial
            </p>
          </div>

          {/* Company Info */}
          <div className="space-y-2 text-center">
            <div className="flex items-center justify-center gap-2 text-xs md:text-sm text-muted-foreground">
              <MapPin className="w-3 h-3 md:w-4 md:h-4 text-primary" />
              <span>Divino – MG</span>
            </div>
            <div className="flex items-center justify-center gap-2 text-xs md:text-sm text-muted-foreground">
              <User className="w-3 h-3 md:w-4 md:h-4 text-primary" />
              <span>Ícaro Vitor</span>
            </div>
            <div className="flex items-center justify-center gap-2 text-xs md:text-sm text-muted-foreground">
              <Rocket className="w-3 h-3 md:w-4 md:h-4 text-primary" />
              <span>MIDAS</span>
            </div>
          </div>

          {/* Links */}
          <div className="space-y-1.5 md:space-y-2 text-center md:text-right">
            <a href="#" className="block text-xs md:text-sm text-muted-foreground hover:text-foreground transition-colors">
              Política de Privacidade
            </a>
            <a href="#" className="block text-xs md:text-sm text-muted-foreground hover:text-foreground transition-colors">
              Termos de Uso
            </a>
            <button
              onClick={() => document.querySelector('#contato')?.scrollIntoView({ behavior: 'smooth' })}
              className="text-xs md:text-sm text-primary hover:text-primary/80 transition-colors"
            >
              Fale Conosco
            </button>
          </div>
        </div>

        {/* Copyright */}
        <div className="mt-8 md:mt-10 lg:mt-12 pt-6 md:pt-8 border-t border-border text-center">
          <p className="text-xs md:text-sm text-muted-foreground">
            © 2026 comercIA – Todos os direitos reservados.
          </p>
        </div>
      </div>
    </footer>
  );
}
